//
//   Author: Ing.Carlos Alberto Diaz Raigosa
//   Correo: aliadas233@gmail.com
//   Contacto: 3045918188-Medellín-Colombia
//
package co.com.tcs.accountadapter;

import co.com.tcs.model.account.Account;
import co.com.tcs.model.account.gateways.AccountRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountAdapter implements AccountRepository {

    @Override
    public Account create(Account account) {
        return null;
    }

    @Override
    public Account get(String type, long number) {
        return Account.builder()
                .type("CC")
                .number(98526462)
                .balance(Double.valueOf(100000))
                .build();
    }

    @Override
    public List<Account> getAll() {
        return null;
    }

    @Override
    public Account save(Account account) {
        return null;
    }

    @Override
    public Account update(Account account) {
        return null;
    }

    @Override
    public boolean delete(String type, long number) {
        return false;
    }
}
