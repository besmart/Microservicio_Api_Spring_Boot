//
//   Author: Ing.Carlos Alberto Diaz Raigosa
//   Correo: aliadas233@gmail.com
//   Contacto: 3045918188-Medellín-Colombia
//
package co.com.tcs.jpa;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(AccountPK.class)
@Table(name= "tbl_account")
public class AccountEntity {
    @Id
    private String type;
    @Id
    private long number;
    @Column
    private Double balance;
    @Column
    private Boolean status;
    @Column(name = "date_creation") private String dateCreation;
    @Column(name = "user_creation") private String userCreation;
}
