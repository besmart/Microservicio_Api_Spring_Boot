//
//   Author: Ing.Carlos Alberto Diaz Raigosa
//   Correo: aliadas233@gmail.com
//   Contacto: 3045918188-Medellín-Colombia
//
package co.com.tcs.jpa;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountPK  implements Serializable {
    private String type;
    private long number;
}
