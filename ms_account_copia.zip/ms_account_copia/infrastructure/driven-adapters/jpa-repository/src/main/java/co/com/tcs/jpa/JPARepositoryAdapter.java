package co.com.tcs.jpa;

import co.com.tcs.jpa.helper.AdapterOperations;
import co.com.tcs.model.account.Account;
import co.com.tcs.model.account.gateways.AccountRepository;
import org.reactivecommons.utils.ObjectMapper;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Primary
public class JPARepositoryAdapter extends AdapterOperations<Account, AccountEntity, AccountPK, JPARepository>
implements AccountRepository
{

    public JPARepositoryAdapter(JPARepository repository, ObjectMapper mapper) {
        /**
         *  Could be use mapper.mapBuilder if your domain model implement builder pattern
         *  super(repository, mapper, d -> mapper.mapBuilder(d,ObjectModel.ObjectModelBuilder.class).build());
         *  Or using mapper.map with the class of the object model
         */
        super(repository, mapper, d -> mapper.map(d, Account.class/* change for domain model */));
    }

    @Override
    public Account create(Account account) {

        return this.save(account);
    }

    @Override
    public Account get(String type, long number) {
       var PK = AccountPK.builder()
               .type(type)
               .number(number).build();
        return  this.findById(PK);
    }

    @Override
    public List<Account> getAll() {
        return this.findAll();
    }

    @Override
    public Account update(Account account){
        return this.save(account);
    }
    @Override
    public boolean delete(String type, long number) {
        var PK = AccountPK.builder()
                .type(type)
                .number(number).build();
        return this.delete(PK);
    }
}
