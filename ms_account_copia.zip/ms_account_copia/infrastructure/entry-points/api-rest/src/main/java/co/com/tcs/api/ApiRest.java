//
//   Author: Ing.Carlos Alberto Diaz Raigosa
//   Correo: aliadas233@gmail.com
//   Contacto: 3045918188-Medellín-Colombia
//

package co.com.tcs.api;
import co.com.tcs.model.account.Account;
import co.com.tcs.usecase.account.AccountUseCase;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/account", produces = MediaType.APPLICATION_JSON_VALUE)
@RequiredArgsConstructor
public class ApiRest {
   private final AccountUseCase useCase;

    @GetMapping(path = "/get")
    public Account getAccount(@RequestParam String type, @RequestParam long number) {
         return useCase.getAccount(type, number);
    }

    @GetMapping(path = "/getAll")
    public List<Account> getAccounts() {
        return useCase.getAccounts();
    }

    @PostMapping(path = "/create")
    public Account saveAccount(@RequestBody Account account) {

        return useCase.createAccount(account);
    }

    @PostMapping(path = "/update")
    public Account updateAccount(@RequestBody Account account) {
        return useCase.updateAccount(account);
    }

    @DeleteMapping(path = "/delete")
    public boolean deleteAccount(@RequestParam String type, @RequestParam long number) {
        return useCase.deleteAccount(type, number);
    }

}
