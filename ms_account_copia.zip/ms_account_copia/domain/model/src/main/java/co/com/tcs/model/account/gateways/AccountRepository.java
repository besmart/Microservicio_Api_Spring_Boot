//
//   Author: Ing.Carlos Alberto Diaz Raigosa
//   Correo: aliadas233@gmail.com
//   Contacto: 3045918188-Medellín-Colombia
//
package co.com.tcs.model.account.gateways;

import co.com.tcs.model.account.Account;

import java.util.List;

public interface AccountRepository {
    public Account create(Account account);
    public Account get(String type, long number);
    public List<Account> getAll();

    Account save(Account account);

    public Account update(Account account);
    public boolean delete (String type, long number);
}
