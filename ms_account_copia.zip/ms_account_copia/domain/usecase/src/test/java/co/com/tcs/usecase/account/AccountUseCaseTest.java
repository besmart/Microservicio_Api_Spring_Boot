package co.com.tcs.usecase.account;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AccountUseCaseTest {

    @AfterEach
    void tearDown() {
    }

    @Test
    void getAccount() {
    }

    @BeforeEach
    void setUp() {
    }

    @Test
    void testGetAccount() {
    }
}