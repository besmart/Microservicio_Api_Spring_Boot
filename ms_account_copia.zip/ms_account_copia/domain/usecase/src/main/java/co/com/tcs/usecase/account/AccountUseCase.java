package co.com.tcs.usecase.account;

import co.com.tcs.model.account.Account;
import co.com.tcs.model.account.gateways.AccountRepository;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;

import java.util.List;

@RequiredArgsConstructor
@AllArgsConstructor
public class AccountUseCase {
    private AccountRepository accountRepository;
    public Account getAccount(String type, long number){

        return this.accountRepository.get(type, number);
    }
    public List<Account> getAccounts(){
        return this.accountRepository.getAll();
    }

    public Account createAccount(Account account){
        return this.accountRepository.create(account);
    }

    public Account updateAccount(Account account){

        return this.accountRepository.update(account);
    }

    public boolean deleteAccount(String type, long number){

        return this.accountRepository.delete(type, number);
    }
}
