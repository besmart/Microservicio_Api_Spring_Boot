//
//   Author: Ing.Carlos Alberto Diaz Raigosa
//   Correo: aliadas233@gmail.com
//   Contacto: 3045918188-Medellín-Colombia
//
package co.com.tcs.config;

import co.com.tcs.model.account.gateways.AccountRepository;
import co.com.tcs.usecase.account.AccountUseCase;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

@Configuration
public class UseCasesConfig {
        @Bean
        AccountUseCase accountUseCase(AccountRepository accountRepository){
                return new AccountUseCase(accountRepository);

        }
}
